Magic Brawl Odyssey - press kit
================================

2D fantasy beat 'em up and action RPG for Android with online co-op for up to 8 players
or solo offline with AI heroes. 15 heroes, 7 worlds, 175 levels.

Developer:    Konolf Studio (one-person studio)
Release:      12 November 2026, Android (Google Play)
Price:        free to download; optional ad clips (only when the player starts them) and in-app purchases.
              Adventure Pack (all worlds and heroes, ends all ad offers): launch price EUR 2.99 until
              31 December 2026, then EUR 6.99
Players:      1 (offline) or 2-8 (online co-op, room code or public tables, no chat)
Languages:    14 in the game
Age rating:   PEGI 12 / USK 12 / ESRB Teen
Google Play:  https://play.google.com/store/apps/details?id=com.magicbrawlodyssey.game
Trailer:      https://www.youtube.com/watch?v=wWYMmi1Jr6E
Browser demo: https://konolfstudio.itch.io/magic-brawl-odyssey
Press kit:    https://konolfstudio.app/presskit/magic-brawl-odyssey/
Contact:      support@konolfstudio.app (promo codes for the Adventure Pack on request)

Folders
  screenshots/  real in-game pictures, 1920 x 1080, no captions
  key-art/      key art with and without title, 1920 x 1080; Google Play feature graphic 1024 x 500
  logo/         app icon 512 x 512, title logo (transparent PNG)
  heroes/       all 15 heroes as transparent cut-outs

You may use these pictures and the trailer for articles, videos and streams about the game.
